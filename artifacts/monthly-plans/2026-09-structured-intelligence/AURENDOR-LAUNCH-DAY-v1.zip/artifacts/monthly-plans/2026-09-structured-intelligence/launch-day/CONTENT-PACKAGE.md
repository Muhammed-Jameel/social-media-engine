# AURENDOR launch-day content package

Three Arabic announcement carousels scheduled across launch day. Every carousel contains six 1080×1350 slides and two supporting 1080×1920 Story backgrounds.

## Publishing order

### SEP-01 — هذا هو أورندور

- Publish: 2026-09-01T10:00:00+03:00
- Platforms: Instagram, LinkedIn
- Purpose: من نحن
- Asset folder: `artifacts/monthly-plans/2026-09-structured-intelligence/launch-day/SEP-01`

Caption:

نحن أورندور، شركة تقنية عراقية تبني بنية تشغيلية ذكية للأعمال المعقّدة. نبدأ من واقع الفريق: أين تضيع المعلومة؟ أين تتكرر الخطوة؟ وأين يتأخر القرار؟ ثم نحوّل هذا المسار إلى نظام يمكن رؤيته، متابعته، وتحسينه—بالذكاء الاصطناعي والأتمتة والأنظمة الرقمية المخصصة. هذه بداية سلسلة نوضح فيها كيف نفكر، ماذا نبني، ولمن.

احفظ المنشور وتابع الجزأين التاليين، وقل لنا: أين يبدأ التعقيد في عملك؟

Slides:

1. **1. هذا هو أورندور** — نبني الوضوح داخل العمل المعقّد.
1. **2. شركة تقنية عراقية** — نبني بنية تشغيلية ذكية للأعمال التي تحتاج رؤية وتحكمًا أوضح.
1. **3. نبدأ من واقع فريقك** — معلومة تضيع · خطوة تتكرر · قرار يتأخر
1. **4. نحوّل المسار إلى نظام** — حالة مرئية · مسؤولية واضحة · خطوة تالية معروفة
1. **5. نفهم. نبني. نقيس.** — لا نفترض النتيجة؛ نختبرها على مسار واضح.
1. **6. أين يبدأ التعقيد في عملك؟**

Supporting Stories:

1. **Story 1 · before_post** — أين يتعطل العمل عندكم أكثر؟ · Native sticker: question (أين يتعطل العمل عندكم أكثر؟)
1. **Story 2 · after_post** — من نحن؟ وماذا نبني؟ الجواب في أول ٦ شرائح. · Native sticker: open_post (افتح المنشور وشاركنا تجربتك)

### SEP-02 — هكذا نعمل

- Publish: 2026-09-01T14:30:00+03:00
- Platforms: Instagram, LinkedIn
- Purpose: طريقة عمل أورندور
- Asset folder: `artifacts/monthly-plans/2026-09-structured-intelligence/launch-day/SEP-02`

Caption:

في أورندور لا نبدأ باسم الأداة. نرسم ما يحدث اليوم: المدخلات، القرارات، المسؤوليات، الاستثناءات، ومصادر البيانات. بعدها نختار الطبقة المناسبة—ربط، أتمتة، مساعد ذكاء، أو نظام تشغيلي مخصص—ثم نختبر المسار ونقيس أثره. التقنية تخدم طريقة العمل؛ لا تستبدل فهمها.

احفظ الخريطة، وسمِّ أول مسار تريد أن نرسمه داخل فريقك.

Slides:

1. **1. هكذا نعمل** — من مسار مبهم إلى نظام يمكن فهمه وقياسه.
1. **2. ١ — نرسم ما يحدث اليوم** — مدخلات · أدوات · تسليمات · نقاط انتظار
1. **3. ٢ — نحدد نقاط القرار** — من يقرر؟ ما القاعدة؟ أين الاستثناء؟ ومن يملك الصلاحية؟
1. **4. ٣ — نبني الطبقة المناسبة** — ربط · أتمتة · مساعد ذكاء · نظام مخصص
1. **5. ٤ — نختبر ونقيس** — خط أساس واضح، تجربة محددة، ودليل قبل التوسع.
1. **6. أي مسار يحتاج وضوحًا عندكم أولًا؟**

Supporting Stories:

1. **Story 1 · before_post** — شنو يستهلك وقتكم أكثر؟ · Native sticker: poll (شنو يستهلك وقتكم أكثر؟)
1. **Story 2 · after_post** — حوّلنا طريقة عملنا إلى خريطة من ٤ خطوات. · Native sticker: open_post (افتح المنشور وشاركنا تجربتك)

### SEP-03 — ماذا تقدم أورندور؟

- Publish: 2026-09-01T19:00:00+03:00
- Platforms: Instagram, LinkedIn
- Purpose: ما نقدمه
- Asset folder: `artifacts/monthly-plans/2026-09-structured-intelligence/launch-day/SEP-03`

Caption:

نقدّم في أورندور أربعة مسارات مترابطة: أنظمة الذكاء والأتمتة للعمليات المتكررة، أنظمة معرفة واسترجاع موثوق للمعلومات المؤسسية، أنظمة تشغيلية مخصصة للبيانات والصلاحيات والتكاملات، وBunyan Pro لرؤية ومتابعة عمليات المشاريع الإنشائية. الاختيار يبدأ من شكل العمل والمشكلة، ثم يأتي دور التقنية.

مرّر الشرائح وحدد المسار الأقرب لحاجتك، أو أرسل لنا وصفًا مختصرًا للمشكلة.

Slides:

1. **1. ماذا تقدم أورندور؟** — أربع طرق نبني بها عملًا أوضح.
1. **2. ١ — ذكاء وأتمتة** — نرسم الخطوات المتكررة، نربط أدواتها، ونبني لها قاعدة وتصعيدًا واضحين.
1. **3. ٢ — أنظمة معرفة واسترجاع** — وصول منضبط إلى إجابات مبنية على وثائق ومصادر مؤسسية معتمدة.
1. **4. ٣ — أنظمة تشغيلية مخصصة** — تطبيقات، لوحات، بيانات، صلاحيات، وتكاملات مصممة لمسار فريقك.
1. **5. ٤ — Bunyan Pro** — رؤية تقدم المشروع وملفاته وصوره ومتابعاته في مكان أوضح.
1. **6. أي مسار أقرب لحاجتك اليوم؟**

Supporting Stories:

1. **Story 1 · before_post** — مهمة تتكرر بقاعدة واضحة تحتاج غالبًا… · Native sticker: quiz (مهمة تتكرر بقاعدة واضحة تحتاج غالبًا…)
1. **Story 2 · after_post** — جمّعنا عروض أورندور الأربعة في منشور واحد. · Native sticker: open_post (افتح المنشور وشاركنا تجربتك)

## Platform handoff

- Upload carousel slides in numeric order; do not mix files between SEP folders.
- Add the native question, poll, quiz, or linked-post sticker inside the reserved Story panel.
- Verify Arabic shaping and line breaks in the platform preview.
- Keep hashtags restrained: zero to three on Instagram and zero to two on LinkedIn; use only tags relevant to the specific post.
- Do not publish until the owner approves the exact caption and asset hashes shown in Content.
