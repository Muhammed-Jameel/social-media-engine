# AURENDOR launch-day design asset plan

The announcement system uses only owned, canonical assets. External resources would not materially improve these diagram-led carousels and would add avoidable licensing and visual-consistency risk.

1. Official AURENDOR horizontal marks — source: `apps/web/public/brand`; used at a restrained, fixed size in every frame.
2. Ghroob Arabic ITF — source: AURENDOR FINAL 2026 font package; used for all Arabic display and body copy with no tracking.
3. Dh Ranclo Bold — source: AURENDOR FINAL 2026 font package; used only for small Latin metadata and Bunyan Pro labeling.
4. Original CSS/SVG system diagrams — created for this launch; used instead of stock photography, generic AI imagery, or decorative people.

License posture: project-owned brand assets only. No external license or attribution is required for this package.
